#ifndef SERVER_H
#define SERVER_H

int start_server(int argc, char **argv);

#endif