#ifndef CLIENT_H
#define CLIENT_H

int start_client(int argc, char **argv);


#endif